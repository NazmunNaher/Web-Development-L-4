<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="one">
    Welcome
<h1>DMPI</h1>
<?php
echo '<h1> Nazmun Nahar</h1>';
echo '<h2>Roll-143598  </h2>';
echo '<h3> Dept.Computer  </h3>';
 
$num1=50;
$num2=60;
$result=$num1+$num2;
echo $result;

?>
    </div>
    <div class="two">
        <h5>Menu</h5>
    </div>
   
    
</body>
</html>