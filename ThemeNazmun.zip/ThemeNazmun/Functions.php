<?php
wp_enqueue_style('style-nazmun', get_stylesheet_uri());
wp_enqueue_style('style-boot', get_template_directory_uri().'/assets/css/bootstrap.min.css');
?>