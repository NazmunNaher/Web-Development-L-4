<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <?php wp_head();?>
</head>
<body>
    <!-- Top bar part start -->
<header class="cont">
<div class="row topbar">
    <div class="col-lg-6 topbar_left">
       <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
    </div>
    <div class="col-lg-6 topbar_right text-end">
        <p>২৬ কার্তিক, ১৪২৯</p>
        <a href="#">English</a>
    </div>
</div>
</header>
<!-- Top bar part end -->
<!-- logo part start -->
<section class="cont">
    <div class="row logo">
        <div class="col-lg-5 logo_left">
            <a href="">
          <?php the_custom_logo();?>    
            <!-- <img src="<?=get_template_directory_uri()?>./assets/img/logo_bn.png"alt="logo"> -->
          </a>
        </div>
        <div class="col-lg-5 logo_search">
            <form action="">
                <input type="text" placeholder="খুঁজুন ">
                <button>অনুসন্ধান</button>
            </form>
        </div>
        <div class="col-lg-2 logo_right d-flex justify-content-end">
            <div class="logo1">
                <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/a2i-logo-footer.png" alt=""></a>
                </div>
                <div class="logo2">
                    <h5>সাথে থাকুন:</h5>
                    <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/facebook-icon.png" alt=""></a>
                    <a href=""><img src="<?=get_template_directory_uri()?>./assets/img//gplus-icon.png" alt=""></a>
                    <a href=""><img src="<?=get_template_directory_uri()?>./assets/img//twitter-blue-icon.png" alt=""></a>
                    <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/youtube-icon.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- logo part end -->
<!-- menu part start -->
<section class="cont">
  <div class="row main-menu">
      <nav class="navbar navbar-expand-lg bg-light">
          <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">


<?php wp_nav_menu([
  'theme_location'=>'TM',
  'theme_class'=>'navbar-nav menu_top'
]);?>


              <!-- <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#">হোম</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">বাংলাদেশ সম্পর্কিত</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">ই-সেবাসমূহ</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">সেবাখাত</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">ব্যবসা-বাণিজ্য</a>
                </li>
                
                <li class="nav-item">
                  <a class="nav-link" href="#">বৈদেশিক বিনিয়োগ</a>
                </li>
                
                <li class="nav-item">
                  <a class="nav-link" href="#">আইন-বিধি</a>
                </li>
                
                <li class="nav-item">
                  <a class="nav-link" href="#">তথ্য বাতায়ন</a>
                </li>
                
                <li class="nav-item">
                  <a class="nav-link" href="#">সেবাকুঞ্জ</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">ফরমস</a>
                </li>
              </ul> -->
            </div>
          </div>
        </nav>
  </div>
</section>
<!-- menu part end -->
<!-- hero part start -->
<section class="cont">
    <div class="row hero">
        <div class="col-lg-8 hero_main">
            <!-- banner part start -->
            
            <div class="banner">
            <a href="">
              <?php dynamic_sidebar('mainbanner');  ?>
            </a>
          <!-- <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/padmabanner.jpg" class="d-block w-100" alt=""></a> -->
            </div>
            <!-- banner part end -->
      

            <!-- slider part start -->
            <div class="slider">
                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
                        <?php
                        $qry= new WP_Query([
                          'post_type'=>'post',
                          'category_name'=>'slider-1'
                        ]);
                        ?>
                        <div class="carousel-inner">
                             <?php
                             $x=0; 
                             while($qry->have_posts()){$qry->the_post();
                              $x++;
                             ?>
                            <div class="carousel-item <?=($x==1)?'active':''?>">
                              <?php the_post_thumbnail();?>
                              <!-- <img src="<?=get_template_directory_uri()?>./assets/img/slider/4-02.jpg" class="d-block w-100" alt="..."> -->
                            </div>
                            <?php }?>
                        </div>
                     
                  </div>
            </div>
             <!-- slider part end -->
             <!-- tab part start -->
            <div class="tab">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                      <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
                    </li>
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                    <?php
                          $qry2 = new WP_Query([
                            'post_type'=>'post',
                            'category_name'=>'জনপ্রিয়_সেবা'
                          ]);
                          ?>
                        <div class="row text-center">
                                <?php 
                                while($qry2->have_posts()){$qry2->the_post();
                                ?>
                            <div class="col-lg-2 ">
                                <a href="">
                                  <?php the_post_thumbnail();?> <br>
                                <!-- <img src="<?=get_template_directory_uri()?>./assets/img/agriculture.png" alt=""><br><p> -->
                                  <?php the_title();?>
                                <!-- কৃষি</p> -->
                               </a>
                            </div>
                            <?php }?>
                            <!-- <div class="col-lg-2">
                                <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/agriculture.png" alt=""><p>কৃষি</p></a>
                            </div>
                            <div class="col-lg-2">
                                <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/agriculture.png" alt=""></a>
                            </div>
                            <div class="col-lg-2">
                                <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/agriculture.png" alt=""></a>
                            </div> -->
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">...</div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">...</div>
                    <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">...</div>
                  </div>
            </div>
              <!-- tab part start -->
            <div class="list"> 
               <h5>উদ্যোগ</h5>
                <ul>
                    <li><a href=""> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a></li>
                    <li><a href="">বাংলাদেশে ঘূর্ণিঝড়ের জরুরি প্রস্তুতি পরিকল্পনা।</a></li>
                    <li><a href="">বাংলাদেশ সরকারের ষষ্ঠ পঞ্চবার্ষিক পরিকল্পনা। </a></li>
                    <li><a href="">বাংলাদেশ সরকারের প্রেক্ষিত পরিকল্পনা (২০১০-২০২১)।</a></li>
                    <li><a href="">দূর্যোগ ব্যবস্থাপনা জন্য জাতীয় পরিকল্পনা ২০১০-২০১৫।</a></li>
                </ul>
            </div>
            <div class="others">
            </div>
        </div>
        <div class="col-lg-4 hero_side">
            <div class="side-img">

            <a href="">
              <?php dynamic_sidebar('simg');?>
            <!-- </a>
                <a href=""> <img src="<?=get_template_directory_uri()?>./assets/img/sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""> </a>
                <a href=""> <img src="<?=get_template_directory_uri()?>./assets/img//sidebar/discount_bn.jpg" class="d-block w-100 mb-2" alt=""> </a>
                <a href=""> <img src="<?=get_template_directory_uri()?>./assets/img/sidebar/Jonotar-Sorkar-banner-Bangl (1).jpg" class="d-block w-100 mb-2" alt=""> </a>
                <a href=""> <img src="<?=get_template_directory_uri()?>./assets/img/sidebar/mygov_bn.jpg" class="d-block w-100 mb-2" alt=""> </a>
                <a href=""> <img src="<?=get_template_directory_uri()?>./assets/img/sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""> </a>
                <a href=""> <img src="<?=get_template_directory_uri()?>./assets/img/sidebar/Tamplate_govtjob_bn.png" class="d-block w-100 mb-2" alt=""> </a> -->
            </div>
            <h5>সকল বাতায়ন</h5>
            <form action="">
          <select name="" id="">
            <option value="">ওয়েবসাইট বাছাই করুন</option>
            <option value="">মন্ত্রণালয়</option>
            <option value="">অধিদপ্তর </option>
            <option value="">ঢাকা বিভাগ</option>
            <option value="">চট্টগ্রাম বিভাগ</option>
            <option value="">রাজশাহী বিভাগ</option>
            <option value="">খুলনা বিভাগ</option>
            <option value="">বরিশাল বিভাগ</option>
            <option value="">রংপুর বিভাগ </option>
            <option value="">সিলেট বিভাগ</option>
          </select>
          <button>চলুন</button>
            </form>
            <div class="side_video">
            
                <h5>মুজিব১০০ আ্যাপ</h5>
                <?php dynamic_sidebar('svideo');?>
                <!-- <iframe width="315" height="200" src="<?=get_template_directory_uri()?>https://www.youtube.com/embed/4Om3kZJL-qU" title="MUJIB100 APP | Speeches, Quotes, Books & More | Get Inspired Everyday" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
                <h5>মাস্ক পরুন সেবা নিন</h5>
                <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/sidebar/mask-bd-portal (1).jpg" class="d-block bb w-100" alt=""></a>
                <h6>ডেঙ্গু প্রতিরোধে করণীয়</h6>
                <a href=""><img src="<?=get_template_directory_uri()?>./assets/img/sidebar/dengu.jpg"class="d-block w-100" alt=""></a>
            </div>
        </div>
    </div>
</section>
<!-- hero part end -->
<!-- footer part start -->

<footer class="cont">
  <div class="row footer_top mt-5">
    <img src="<?=get_template_directory_uri()?>./assets/img/footer/download.png" alt="">
  </div>
  <div class="row footer_bottom">
    <div class="col-lg-8 fb_left">
      <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">

        <?php wp_nav_menu([
  'theme_location'=>'FM',
  'theme_class'=>'navbar-nav menu_bottom'
])?>


          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

              <li class="nav-item">
                <a class="nav-link" href="#">গোপনীয়তার নীতিমালা</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">ব্যবহারের শর্তাবলি</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">সার্বিক সহযোগিতায়</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">সাইট ম্যাপ</a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="#">সচরাচর জিজ্ঞাসা</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
  <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২২-১০-৩০ ০৮:৩৫:০১</p>
    </div>
    <div class="col-lg-4 fb_right text-end ">
      <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
      <img src="<?=get_template_directory_uri()?>./assets/img/footer/np-logo-set.png" alt="">
    </div>
  </div>
</footer>
<?php wp_footer();?>
<!-- footer part end -->

<script src="<?=get_template_directory_uri()?>./assets/js/bootstrap.bundle.min.js"></script>


<section class="cont">
<div class="row branching text-center pt-5 pb-5">
<div class="col-sm-4 bl">

<?php
$num=10;
while($num<=100){
  if($num%2==0){
  echo $num. '<br>';

}else{
  echo'';

}
$num= $num+5;
}
?>


</div>
<div class="col-sm-4 bm">
  <?php
$Mark=50;
if($Mark>=40){
  print ' <h1> Pass </h1>';
}else{
print '<h1>Fail</h1>';
}
?>
</div>
<div class="col-sm-4 br">
<?php
$Mark=30;
echo($Mark>=40)? '<h1>Pass</h1>': '<h1>Fail</h1>';
?>
</div>

</div>


  </section>



</body>
</html>