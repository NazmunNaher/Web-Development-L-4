<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri().'/assets/css/bootstrap.min.css ');
wp_enqueue_script( 'script-name', get_template_directory_uri().'/assets/js/bootstrap.bundle.min.js ');


add_theme_support( 'custom-logo', array(
	'height'               => 100,
	'width'                => 400,
	'flex-height'          => true,
	'flex-width'           => true,
	'header-text'          => array( 'site-title', 'site-description' ),
	'unlink-homepage-logo' => true,
) );
add_theme_support('post-thumbnails');

register_nav_menus([
    'TM'=>'Primary-1',
    'FM'=>'Footer'
]);

register_sidebar([
    'name'=>'Main Banner',
    'id'=>'mainbanner',
    'before_widget'=>'',
    'after_widget'=>'',
]);
register_sidebar([
    'name'=>'Side Video',
    'id'=>'svideo',
    'before_widget'=>'',
    'after_widget'=>'',
]);
register_sidebar([
    'name'=>'Side Image',
    'id'=>'simg',
    'before_widget'=>'',
    'after_widget'=>'',
]);


?>
